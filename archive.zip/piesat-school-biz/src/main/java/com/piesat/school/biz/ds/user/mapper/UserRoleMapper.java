package com.piesat.school.biz.ds.user.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.piesat.school.biz.ds.user.entity.UserRole;

public interface UserRoleMapper extends BaseMapper<UserRole> {
}
