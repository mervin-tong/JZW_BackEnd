package com.piesat.school.biz.ds.user.service;

import com.piesat.school.biz.ds.user.entity.UserRole;

public interface IUserRoleService {
    //添加用户-角色表对应数据
    void addUserRole(UserRole userRole);
}
