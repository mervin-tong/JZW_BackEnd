package com.piesat.school.biz.ds.order.mapper;

import com.piesat.school.biz.ds.order.entity.Attention;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author 周悦尧
 * @since 2022-03-08
 */
public interface AttentionMapper extends BaseMapper<Attention> {

}
