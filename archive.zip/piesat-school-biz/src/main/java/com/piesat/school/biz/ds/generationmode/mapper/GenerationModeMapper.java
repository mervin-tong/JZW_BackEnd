package com.piesat.school.biz.ds.generationmode.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.piesat.school.biz.ds.generationmode.entity.GenerationMode;


public interface GenerationModeMapper extends BaseMapper<GenerationMode> {
}
