package com.piesat.school.biz.ds.order.mapper;

import com.piesat.school.biz.ds.order.entity.HistoryDownload;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author suweipeng
 * @since 2022-03-08
 */
public interface HistoryDownloadMapper extends BaseMapper<HistoryDownload> {

}
