package com.piesat.school.biz.ds.method.service;

import com.piesat.school.biz.ds.method.entity.Method;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 数据生成方法 服务类
 * </p>
 *
 * @author 周悦尧
 * @since 2022-01-17
 */
public interface IMethodService extends IService<Method> {

}
