package com.piesat.school.biz.ds.information.mapper;

import com.piesat.school.biz.ds.information.entity.Information;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author suweipeng
 * @since 2022-04-11
 */
public interface InformationMapper extends BaseMapper<Information> {

}
