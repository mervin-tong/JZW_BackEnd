package com.piesat.school.biz.ds.order.facade;

/**
 * @author suweipeng
 * @data 2022/2/24 16:06
 */
public class OrderFromFacadeService {

}
