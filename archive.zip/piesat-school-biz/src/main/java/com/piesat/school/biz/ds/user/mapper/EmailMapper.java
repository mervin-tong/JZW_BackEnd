package com.piesat.school.biz.ds.user.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.piesat.school.biz.ds.user.entity.Email;
import org.apache.ibatis.annotations.Mapper;
/**
 * Created with IntelliJ IDEA.
 * @Author: liqiteng
 * @Date: 2022/8/23
 * @Description:
 */
@Mapper
public interface EmailMapper extends BaseMapper<Email> {
}
