package com.piesat.school.biz.ds.aspect.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.piesat.school.biz.ds.aspect.entity.AspectEntity;

public interface AspectMapper extends BaseMapper<AspectEntity> {

}
