package com.piesat.school.rest.constants;

/**
 * @author lawliet
 * @date 2021-08-12
 * <p>
 * 描述内容
 */
public interface DubboConstant {
    String CONSUMER_NAME = "school";
}
