package com.piesat.school.constant;

/**
 * @author 唐子超
 * @date 2021-12-14
 * <p>
 * 用于定义Cache Key
 */
public class CacheConstant {
    public static final String WDL_SYSTEM_CONFIG_CACHE_KEY = "school.wdl.configs";
}
